<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/ecuador.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/isabel.jpg" alt="Isabel" />
		<a href="http://www.isabel.com.ec" target="_blank" >www.isabel.com.ec</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/isabel.png" alt="" />
		<br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">ISABEL</a>
		<br /><br />
		Provenientes de Ecuador y disponibles en dos presentaciones (Aceite y Salsa de Tomate), las Sardinas Isabel llevan la marca de una de las conserveras de pescado m&aacute;s grandes de Espa&ntilde;a, Isabel (del Grupo Conservas Garavilla), sin&oacute;nimo de experiencia y tradici&oacute;n. El producto viene en su tradicional envase ovalado por 425 gramos y ofrece un conveniente precio por kilo en relaci&oacute;n a otras especialidades de la categor&iacute;a de conservas de pescado. Un cl&aacute;sico.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/isabel/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/isabel/1.jpg" alt="" /></a>
			<div class="titulo_producto">Isabel Sardinas<br />Pinchagua en<br />Aceite</div>
			Can Oval x 425g
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/isabel/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/isabel/2.jpg" alt="" /></a>
			<div class="titulo_producto">Isabel Sardinas<br />Pinchagua en<br />Salsa de Tomate </div>
			Can Oval x 425g
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
