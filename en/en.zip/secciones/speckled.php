<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="../imagenes/productos/paises/InglaterraSpeckled-79.png" alt="" /></div>
	<div class="banners_productos">
		<img src="../imagenes/productos/banners/coopers.jpg" alt="COOPERS" />
		<a href="http://www.coopers.com.au/" target="_blank" >www.coopers.com.au</a>
	</div>
	<div class="izquierda_productos">
		<img src="../imagenes/productos/logos/speckled.jpg" alt="" width="150px" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="../imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">OLD SPECKLED HEN</a>
		<br /><br />
		Old Speckled Hen is a light red ale but with a deep flavor: a British classic. 		<br /><br />
		Its rich amber colour is bright with reddish tones and its caramel aroma is superb fruity and malty. This beer is moderately carbonated with medium body and warm flavor followed by a balanced finish that combines bitterness and malty sweetness.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/coopers/1_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/coopers/1.jpg" alt="" /></a>
			<div class="titulo_producto">Old Speckled Hen</div>
			Bottle x 500ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/coopers/2_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/coopers/2.jpg" alt="" /></a>
			<div class="titulo_producto">Old Speckled Hen</div>
			Can x 500ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/coopers/3_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/coopers/3.jpg" alt="" /></a>
			<div class="titulo_producto">Old Speckled Hen</div>
			Keg 30lts (non-returnable)
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
