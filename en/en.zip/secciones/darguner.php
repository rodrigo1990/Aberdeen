<script type="text/javascript" src="../js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="../js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="../imagenes/productos/paises/alemania3.png" alt="" /></div>
	<div class="banners_productos">
		<img src="../imagenes/productos/banners/darguner.jpg" alt="Darguner" />
		<a href="http://www.brauerei-dargun.de" target="_blank" >www.brauerei-dargun.de</a>
	</div>
	<div class="izquierda_productos">
		<img src="../imagenes/productos/logos/darguner.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">DARGUNER</a>
		<br /><br />
		If you are among the so many fans of German pilsner style beer worldwide, you cannot miss the experience of trying a Darguner beer. The brewery is located in the town of Dargun, State of Mecklenburg-Vorpommern, a place where Darguner is one of the most well-known and best-selling brands. Its mild aroma with a touch of well-selected hops, crystal clear water, finest selection of barley malt varieties and its incredible taste will delight you.
		<br /><br />
		If you prefer the typical Bavarian wheat beer style, Darguner might be your best choice as well. DargunerWeissbier, brewed with wheat, barley and caramel malts, keeps a natural turbidity due to the fact that it is unfiltered.It is always brewed according to the German Purity Law.
		<br /><br />
		Darguner, an affordable encounterwith the noble German brewing tradition.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/darguner/1_g.png" data-fancybox-group="gallery" ><img src="../imagenes/productos/darguner/1.png" alt="" /></a>
			<div class="titulo_producto">Darguner<br />Pilsner</div>
			Botella x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/darguner/2_g.png" data-fancybox-group="gallery" ><img src="../imagenes/productos/darguner/2.png" alt="" /></a>
			<div class="titulo_producto">Darguner<br />Pilsner</div>
			Lata x 500ml
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
