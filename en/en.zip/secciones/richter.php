<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/alemania.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/richter.jpg" alt="Richter" />
		<a href="http://www.larsenseafood.com" target="_blank" >www.larsenseafood.com</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/richter.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">RICHTER</a>
		<br /><br />
		Richter herring fillets are delicious specialties developed by Larsen Danish Seafood and they are strongly Nordic! A traditional recipe and ingredients that are carefully selected for the different types of sauces offered make these products a special gift. 
		<br /><br />
		As they are ready to serve, you can enjoy them easily as a perfect, fast dish that will help to soothe your appetite after a hard working day. 
		<br /><br />
		There are four different available options: smoked herring, herring red pepper sauce, herring herb sauce and herring tomato sauce.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/richter/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/richter/1.jpg" alt="" /></a>
			<div class="titulo_producto">Filets de<br />Arenque en Salsa<br />de Mostaza</div>
			Can x 200ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/richter/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/richter/2.jpg" alt="" /></a>
			<div class="titulo_producto">Filets de<br />Arenque en Salsa<br />de Tomate</div>
			Can x 200ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/richter/3_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/richter/3.jpg" alt="" /></a>
			<div class="titulo_producto">Filets de<br />Arenque en Salsa<br />de Finas Hierbas</div>
			Can x 200ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/richter/4_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/richter/4.jpg" alt="" /></a>
			<div class="titulo_producto">Filets de Arenque<br />Ahumados en<br />Aceite</div>
			Can x 190ml
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
