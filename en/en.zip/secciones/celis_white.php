<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/belgica2.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/celis.jpg" alt="CELIS WHITE" />
		<a href="http://www.vansteenberge.com/en/our-beer/other-beers/celis-white/" target="_blank" >www.vansteenberge.com/en/our-beer/other-beers/celis-white/</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/celis.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos"></a>
		Brewer Pierre Celis was responsible for reviving the Witbier style – Belgian wheat beers – when in 1966 he re-opened a brewery to manufacture this kind of beers after it had been closed for more than one decade. His brewery, Hoegaarden, was sold to the large brewing Company InBev in 1988 after it had burned down. Pierre Celis moved to Austin, Texas, where he created the beer that was given his name: Celis White. Currently, Van Steenberge NV has the rights to manufacture the beer in his native Belgium with his original recipe. This is the version that has arrived in Argentina.
		<br /><br />
		Celis White is a white wheat top-fermented beer with a touch of fruit and herbs. <br />
		If served cold, it gets a blurred white appearance and a surprising light taste.
		<br /><br />
		This delicious white beer got all the time it needs to develop and we can describe it with just one word: Amazing!
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/celis/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/celis/1.jpg" alt="" /></a>
			<div class="titulo_producto">Celis White</div>
			Bottle x 250ml
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
