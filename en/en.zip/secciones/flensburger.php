<script type="text/javascript" src="../js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="../js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="../css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="../imagenes/productos/paises/alemania4.png" alt="" /></div>
	<div class="banners_productos">
		<img src="../imagenes/productos/banners/flensburger.jpg" alt="flensburger" />
		<a href="http://www.flens.de" target="_blank" >www.flens.de</a>
	</div>
	<div class="izquierda_productos">
		<img src="../imagenes/productos/logos/flensburger.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">FLENSBURGER </a>
		<br /><br />
		Are you ready for a great beer? If the answer is “yes”, Flensburger beer, the most traditional one from the State of Schleswig-Holstein in Germany, will offer you a unique experience. That distinctive “Plop!” sound is only waiting for you…
		<br /><br />
		That is what you will hear as soon as you open a Swing-Top bottle of Flensburger, a trademark which stands for the inimitably fresh and rich taste that comes from the historic brewery with more than 125 years of expertise.
		<br /><br />
		FlensburgerPilsener will offer you full flavoured aroma and carefully selected hops. You might choose Gold if you prefer a mild beer with a sophisticated hint of hops and light caramel malt. Dunkel is the dark site of pleasure; fine bitter, fresh and rich in taste. Weizen is the top-fermented beer specialty. Frühlingsbockis the right one for you if you’d like to try a strong full-bodied specialty beer, and Winterbock will provide a crisp mild taste.
		<br /><br />
		Enjoy Premium Quality. Open a Flens! Plop!
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/flensburger/1_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/flensburger/1.jpg" alt="" /></a>
			<div class="titulo_producto">Flensburger<br />Pilsener</div>
			Bottle x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/flensburger/2_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/flensburger/2.jpg" alt="" /></a>
			<div class="titulo_producto">Flensburger<br />Gold</div>
			 Bottle x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/flensburger/3_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/flensburger/3.jpg" alt="" /></a>
			<div class="titulo_producto">Flensburger<br />Weizen</div>
			 Bottle x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/flensburger/4_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/flensburger/4.jpg" alt="" /></a>
			<div class="titulo_producto">Flensburger<br />Dunkel</div>
			Bottle x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/flensburger/5_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/flensburger/5.jpg" alt="" /></a>
			<div class="titulo_producto">Flensburger<br />Frühlingsbock</div>
			Bottle x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/flensburger/6_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/flensburger/6.jpg" alt="" /></a>
			<div class="titulo_producto">Flensburger<br />Winterbock</div>
			Bottle x 330ml
		</div>
		<div class="clear"></div><br /><br />

		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/flensburger/7_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/flensburger/7.jpg" alt="" /></a>
			<div class="titulo_producto">Flensburger<br />Pilsener</div>
			Barril 5l
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/flensburger/8_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/flensburger/8.jpg" alt="" /></a>
			<div class="titulo_producto">Flensburger<br />Pilsener</div>
			Bottle x 2l
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
