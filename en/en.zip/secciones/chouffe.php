<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/BelgicaLaChouffe-79.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/darguner.jpg" alt="Darguner" />
		<a href="http://www.brauerei-dargun.de" target="_blank" >www.brauerei-dargun.de</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/chouffe.jpg" style="width:150px" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">LA CHOUFFE</a>
		<br /><br />
		Llega a la Argentina la clásica versión de esta excéntrica cerveza belga: <b>La Chouffe Blonde</b>
		<br /><br />
		Con un hermoso color dorado intense y una corona de espuma cremosa es, literalmente, auténtico placer. Su sabor es especiado, con un toque magistral de cítricos, seguidos del refrescante aroma a cilantro que la vuelven particlarmente fresca. La variedad Blonde de esta magnífica cerveza tiene un carácter loral que se complementa de manera armoniosa con el aroma a plátanos. Se trata de una cerveza suave y armonica, con un final en boca que se caracteriza por su agradable sabor especiado y toques de pimienta.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/chouffe/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/chouffe/1.jpg" alt="" /></a>
			<div class="titulo_producto">La Choufee</div>
			Botella x 330ml
		</div>
		
		
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
