<script type="text/javascript" src="../js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="../js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="../css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="../imagenes/productos/paises/holanda2.png" alt="" /></div>
	<div class="banners_productos">
		<img src="../imagenes/productos/banners/horses.jpg" alt="Horses" />
		<a href="http://www.3horsesmalt.com" target="_blank" >www.3horsesmalt.com</a>
	</div>
	<div class="izquierda_productos">
		<img src="../imagenes/productos/logos/horses.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">3 HORSES MALT</a>
		<br /><br />
		3 Horses Malt is the name of our traditionally produced malt beverage with no alcohol made of the purest waters and finest barley. This classic favourite is a perfect balance of bitter and sweet, guaranteed to quench your thirst on every occasion.
		<br /><br />
		It is the brewing method what sets 3 Horses Malt apart from the rest and what makes it so distinguishable and superior in taste. All the ingredients are carefully selected to ensure the finest quality and a first-class product.
		<br /><br />
		Apart from energy, barley malt provides nutrients, proteins, vitamins and minerals, and for this reason it is daily chosen by sportspeople, children and breastfeeding mothers.
		<br /><br />
		3 Horses Malt, refreshing and nutritional!
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/horses/1_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/horses/1.jpg" alt="" /></a>
			<div class="titulo_producto">3 Horses Dark<br />Malt Beverage</div>
			Botella x 330ml
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
