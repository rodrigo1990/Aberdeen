<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/peru.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/santiago.jpg" alt="Santiago" />
		<a href="http://www.santiagoqueirolo.com" target="_blank" >www.santiagoqueirolo.com</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/santiago.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">SANTIAGO QUEIROLO</a>
		<br /><br />
		Pisco is Peru and Santiago Queirolo is Peruvians’ favourite brand. Pisco, a grape distillate which is traditional from Peru, has a history that dates back to the late XVI century. It is one of Peru's flagship products. Santiago Queirolo Pisco is made in the province of Cañete, Lima, in accordance with traditional processes of distillation in stills. As a result of this, Santiago Queirolo is a high-quality product appreciated by sommeliers from Peru, our country and around the world, which can be found in the finest restaurants as well as at restaurants where traditional food from Peru is served in Buenos Aires. 
		<br /><br />
		You can enjoy it in a typical Pisco Sour cocktail, in a refreshing Chilcano de Pisco or just drink it neat. Whatever option you choose, Santiago Queirolo Pisco is not to be missed! 
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/santiago/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/santiago/1.jpg" alt="" /></a>
			<div class="titulo_producto">Santiago Queirolo<br />Pisco Quebranta</div>
			Bottle x 700ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/santiago/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/santiago/2.jpg" alt="" /></a>
			<div class="titulo_producto">Santiago Queirolo<br />Pisco Quebranta</div>
			Bottle Gal&oacute;n x 4lts
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/santiago/3_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/santiago/3.jpg" alt="" /></a>
			<div class="titulo_producto">Santiago Queirolo<br />Pisco Acholado</div>
			Bottle x 700ml
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
