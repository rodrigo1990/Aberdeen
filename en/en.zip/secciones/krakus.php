<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/PoloniaKrakus-79.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/celis.jpg" alt="CELIS WHITE" />
		<a href="http://www.vansteenberge.com/en/our-beer/other-beers/celis-white/" target="_blank" >www.vansteenberge.com/en/our-beer/other-beers/celis-white/</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/krakus.jpg" alt="" width="215px" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos"></a>
		Los pepinillos bebé Krakus se caracterizan por la utilización de pepinos frescos y pequeños en su elaboración. Se distinguen de los demás por su sabor, su frescura y por ser excepcionalmente crujientes.
 		<br /><br />
 		Todas estas características son posibles gracias a la salmuera dulce especial que se utiliza en su fabricación, con una mezcla de especias como eneldo, ajo, rábano picante, pimienta negra en granos y una gran porción de semillas de mostaza que son un sosticado revés hacia el sabor dulce del pepinillo. 
		<br /><br />
		Los pepinillos bebé Krakus son un aperitivo y aditivo ideal para satisfacer los platos en cualquier ocasión. En familia, con amigos, sólo o acompañado. El exquisito sabor de Krakus es ideal para acompañar cualquier tipo de comida.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/krakus/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/krakus/1.jpg" alt="" /></a>
			<div class="titulo_producto">Krakus <br> Pickled Dill <br> Cucumbers</div>
			Frasco x 450 grs
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/krakus/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/krakus/2.jpg" alt="" /></a>
			<div class="titulo_producto">Krakus <br> Pickled Dill <br> Cucumbers</div>
			Frasco x 450 grs
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
