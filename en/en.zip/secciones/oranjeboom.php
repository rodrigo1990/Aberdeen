<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/holanda.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/oranjeboom.jpg" alt="Oranjeboom" />
		<a href="http://www.udbexport.com/en/brands/1-oranjeboom.html" target="_blank" >www.udbexport.com/en/brands/1-oranjeboom.html</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/oranjeboom.png" alt="" />
		<br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">ORANJEBOOM</a>
		<br /><br />
		Traditional and Contemporary beer. Oranjeboom has a long and rich history which continues until today through the canals of Amsterdam. The word Oranjeboom, which means orange tree, is deeply linked to the history of Holland. Since the XVI century the Royal Family –which still continues to govern- has belonged to the House of Orange-Nassau, while the orange blossom or the orange tree have always been symbols of the closeness between the Dutch people and their Monarchy.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/oranjeboom/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/oranjeboom/1.jpg" alt="" /></a>
			<div class="titulo_producto">Oranjeboom<br />Original</div>
			Bottle x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/oranjeboom/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/oranjeboom/2.jpg" alt="" /></a>
			<div class="titulo_producto">Oranjeboom<br />Original</div>
			Can x 500ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/oranjeboom/3_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/oranjeboom/3.jpg" alt="" /></a>
			<div class="titulo_producto">Oranjeboom<br />8.5 Extra Strong</div>
			Can x 500ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/oranjeboom/4_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/oranjeboom/4.jpg" alt="" /></a>
			<div class="titulo_producto">Oranjeboom<br />12 Super Strong</div>
			Can x 500ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/oranjeboom/5_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/oranjeboom/5.jpg" alt="" /></a>
			<div class="titulo_producto">Oranjeboom<br />14 Ultra Strong</div>
			Can x 500ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/oranjeboom/6_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/oranjeboom/6.jpg" alt="" /></a>
			<div class="titulo_producto">Oranjeboom<br />16 Mega Strong</div>
			Can x 500ml
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
