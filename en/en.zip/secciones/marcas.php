<div class="titulos_secciones">Our Brands</div>
<div id="contiene_marcas">
	<div id="izquierda_marcas">
		BEERS
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		OTHER PRODUCTS
		<br /><br /><br /><br /><br /><br /><br /><br /><br />
	</div>
	<div id="derecha_marcas">
		<a href="?s=oranjeboom" ><img src="../imagenes/marcas_nuevas/1.png" alt="" /></a>
		<a href="?s=darguner" ><img src="../imagenes/marcas_nuevas/18.png" alt="" /></a>
		<a href="?s=kronenbourg" ><img src="../imagenes/marcas_nuevas/2.png" alt="" /></a>
		<a href="?s=fullers" ><img src="../imagenes/marcas_nuevas/3.png" alt="" /></a>
		<a href="?s=flensburger" ><img src="../imagenes/marcas_nuevas/20.png" alt="" /></a>
		<a href="?s=gulden_draak" ><img src="../imagenes/marcas_nuevas/4.png" alt="" /></a>
		<br /><br /><br />
		<a href="?s=czechvar" ><img src="../imagenes/marcas_nuevas/5.png" alt="" /></a>
		<a href="?s=weidmann" ><img src="../imagenes/marcas_nuevas/6.png" alt="" /></a>
		<a href="?s=coopers" ><img src="../imagenes/marcas_nuevas/7.png" alt="" /></a>
		<a href="?s=grimbergen" ><img src="../imagenes/marcas_nuevas/11.png" alt="" /></a>
		<a href="?s=piraat" ><img src="../imagenes/marcas_nuevas/12.png" alt="" /></a>
		<a href="?s=hertog" ><img src="../imagenes/marcas_nuevas/13.png" alt="" /></a>
		<br /><br /><br />
		<a href="?s=westmalle" ><img src="../imagenes/marcas_nuevas/8.png" alt="" /></a>
		<a href="?s=celis_white" ><img src="../imagenes/marcas_nuevas/9.png" alt="" /></a>
		
		<br /><br /><br /><br /><br /><br /><br />
		<a href="?s=horses" ><img src="../imagenes/marcas_nuevas/19.png" alt="" /></a>
		<a href="?s=casafiesta" ><img src="../imagenes/marcas_nuevas/14.png" alt="" /></a>
		<a href="?s=louisiana" ><img src="../imagenes/marcas_nuevas/15.png" alt="" /></a>
		<a href="?s=richter" ><img src="../imagenes/marcas_nuevas/16.png" alt="" /></a>
		<a href="?s=santiago" ><img src="../imagenes/marcas_nuevas/17.png" alt="" /></a>
		<br /><br />
		
		<a href="?s=inkakola" ><img src="../imagenes/marcas_nuevas/10.png" alt="" /></a>
		<br />
	</div>
</div>
