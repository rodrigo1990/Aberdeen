<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/eeuu.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/louisiana.jpg" alt="Louisiana Gold" />
		<a href="http://www.lagoldhotsauce.com" target="_blank" >www.lagoldhotsauce.com</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/louisiana.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">LOUISIANA GOLD</a>
		<br /><br />
		Louisiana Gold-style hot sauces were introduced to American people for the first time many decades ago through Cajun cuisine, one of the most traditional styles of ethnic cuisine in the United States. Louisiana Gold Red Pepper Sauce is made with Tabasco chilies and other varieties of fine peppers that have been perfectly aged to get a delicious spicy sauce with an acceptable intensity which does not taste like vinegar, as it is usually the case with some other brands. This allows for a perfect taste of the true and delicious Tabasco pepper! Go for it!
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/louisiana/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/louisiana/1.jpg" alt="" /></a>
			<div class="titulo_producto">Salsa Roja <br />Louisiana Gold</div>
			Bottle x 57ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/louisiana/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/louisiana/2.jpg" alt="" /></a>
			<div class="titulo_producto">Salsa Roja <br />Louisiana Gold</div>
			Bottle x 148ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/louisiana/3_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/louisiana/3.jpg" alt="" /></a>
			<div class="titulo_producto">Salsa Roja <br />Louisiana Gold</div>
			Bottle x 354ml
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
