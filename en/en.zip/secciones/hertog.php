<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/holanda.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/hertog.jpg" alt="HERTOG JAN" />
		<a href="http://www.hertogjan.nl/" target="_blank" >www.hertogjan.nl</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/hertog.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">HERTOG JAN</a>
		<br /><br />
		“Hertog Jan” means Duke John, or John I of Brabant, who is also known in history as John the Victorious. These refined beers have been produced since 1915 in Arcen, a small village in the Dutch province of Limburg, very close to Germany.
		<br /><br />
		Hertog Jan are special Dutch abbey beers that can be found in Argentina in delicate ceramic bottles with cork stoppers. You can think of them as the perfect gift or you might also collect them or gratify yourself, but the most important value of these excellent abbey-style beers will be found inside the product and in their three distinctive styles: Dubbel, Tripel and Grand Prestige. The latter was awarded the gold medal at the World Beer Cup 2014 in the Belgian Style Dark Strong Ale category and it was also the Netherlands Best Vintage Dark Beer in 2015. 
		<br /><br />
		Hertog Jan is not to be missed! 
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/hertog/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/hertog/1.jpg" alt="" /></a>
			<div class="titulo_producto">Hertog Jan<br />Dubbel</div>
			Bottle x 500ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/hertog/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/hertog/2.jpg" alt="" /></a>
			<div class="titulo_producto">Hertog Jan<br />Tripel</div>
			Bottle x 500ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/hertog/3_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/hertog/3.jpg" alt="" /></a>
			<div class="titulo_producto">Hertog Jan<br />Grand Prestige</div>
			Bottle x 500ml
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
