<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/australia.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/coopers.jpg" alt="COOPERS" />
		<a href="http://www.coopers.com.au/" target="_blank" >www.coopers.com.au</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/coopers.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">COOPERS</a>
		<br /><br />
		Coopers Brewery Limited is the largest Australian brewery owned by the Cooper family, in Adelaide, South Australia, where their excellent beers are made since 1862.
		<br /><br />
		These beers are characterized by their secondary fermentation technique –some yeast remains in the bottle, thus the beer contains some sediment.<br />
		Some drinkers like to mix the sediment throughout the beer by tipping or rolling the beer before drinking, while others prefer to decant the beer into a glass leaving most of the sediment at the base of the bottle.
		<br /><br />
		Coopers Pale Ale is the beer that inspired a new generation of ale drinkers. It is fruity and floral as well as balanced with a crisp bitterness.<br />
		Coopers Sparkling Ale is an English style golden ale. It has a distinctive cloudy appearance due to the sediment being left in the bottle. The Sparkling Ale has a slightly different flavour and higher alcoholic content than the Pale Ale.<br />
		Coopers Stout is a consistent award winner in Australia and around the world for its tradition and quality. It is brewed using the choicest raw materials and classic brewing techniques, which produce a beacon for lovers of a hearty brew, with a robust yet complex flavour.
		<br /><br />
		Don’t miss the Australian tradition!<br />
		Don’t miss Coopers!
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/coopers/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/coopers/1.jpg" alt="" /></a>
			<div class="titulo_producto">Coopers<br />Original Pale Ale</div>
			Bottle x 375ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/coopers/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/coopers/2.jpg" alt="" /></a>
			<div class="titulo_producto">Coopers<br />Sparkling Ale</div>
			Bottle x 375ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/coopers/3_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/coopers/3.jpg" alt="" /></a>
			<div class="titulo_producto">Coopers Best<br />Extra Stout</div>
			Bottle x 375ml
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
