<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/repcheca.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/czechvar.jpg" alt="CZECHVAR" />
		<a href="http://www.czechvar.com/index.html" target="_blank" >www.czechvar.com</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/czechvar.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">CZECHVAR</a>
		<br /><br />
		In Bohemia, one of the most important historical regions in the Czech Republic, good beer has been brewed for centuries. The local beer from the city Ceské Budejovice became very famous because of its high quality. 
		<br /><br />
		Budějovický Budvar is the brewer of this excellent beer that we bring to Argentina today. 
		<br /><br />
		This beer is Czechvar– its original name in the Czech Republic and in other countries in Europe is Budweiser Budvar – and only top quality ingredients are used to produce it: yeast that can assure its delicious taste, pure virgin spring water, the best hops and the grain of a unique variety of barley. Besides, there is a period of at least 90 days of lagering in its manufacturing process.
		<br /><br />
		Czechvar comes from the heart of Europe and it’s truly unique. You will love its unmistakable, gentle hop character!
		<br /><br />
		We cannot really describe the flavor of Czechvar beer. It has to be tasted!
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/czechvar/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/czechvar/1.jpg" alt="" /></a>
			<div class="titulo_producto">Czechvar<br />Original Lager</div>
			Can x 500ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/czechvar/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/czechvar/2.jpg" alt="" /></a>
			<div class="titulo_producto">Czechvar<br />Original Lager</div>
			Bottle x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/czechvar/3_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/czechvar/3.jpg" alt="" /></a>
			<div class="titulo_producto">Czechvar Dark<br />Lager</div>
			Bottle x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/czechvar/4_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/czechvar/4.jpg" alt="" /></a>
			<div class="titulo_producto">Czechvar<br />Original Lager</div>
			Barril x 5lts
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
