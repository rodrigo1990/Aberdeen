<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/argentina.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/berlina.jpg" alt="Berlina" />
		<a href="http://www.cervezaberlina.com" target="_blank" >www.cervezaberlina.com</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/berlina.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">BERLINA</a>
		<br /><br />
		Contar con una premiada y exclusiva cerveza Argentina - de la Patagonia - definitivamente enaltece nuestro portfolio de productos del mundo. Berlina Cerveza Patag&oacute;nica es un producto 100% Org&aacute;nico, elaborado artesanalmente en la Patagonia Argentina con las m&aacute;s selectas materias primas y respetando antiguas normas alemanas que datan de 1516.
		<br /><br />
		El apego de Berlina a la tradici&oacute;n cervecera, el profesionalismo de su Brewmaster formado en Berl&iacute;n (Alemania), la calidad de sus ingredientes y las cualidades insuperables del agua patag&oacute;nica, dan por resultado esta Cerveza Artesanal Premium con Denominaci&oacute;n de Origen. La nueva Planta Modelo de Berlina se encuentra en Colonia Suiza, a 30 Kms de San Carlos de Bariloche. En este viejo enclave de colonos europeos, gracias al agua pura de deshielos y la pasi&oacute;n de una empresa familiar, adquiere su esp&iacute;ritu Berlina, Cerveza Patag&oacute;nica. Con Nobleza y Esp&iacute;ritu.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/berlina/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/berlina/1.jpg" alt="" /></a>
			<div class="titulo_producto">Cerveza Rubia<br />Estilo Alem&aacute;n</div>
			Bottle x 355ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/berlina/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/berlina/2.jpg" alt="" /></a>
			<div class="titulo_producto">Cerveza Roja<br />Estilo Ingl&eacute;s</div>
			Bottle x 355ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/berlina/3_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/berlina/3.jpg" alt="" /></a>
			<div class="titulo_producto">Cerveza Negra<br />Estilo Irland&eacute;s</div>
			Bottle x 355ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/berlina/4_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/berlina/4.jpg" alt="" /></a>
			<div class="titulo_producto">Berlina Gift<br />Pack x 3 Cervezas<br />(Golden Ale/IPA/<br />Foreign Stout)</div>
			3 Bottles x 355ml
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
