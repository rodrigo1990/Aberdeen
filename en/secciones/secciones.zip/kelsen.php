<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/dinamarca.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/kelsen.jpg" alt="Kelsen" />
		<a href="http://www.kelsen.com" target="_blank" >www.kelsen.com</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/kelsen.png" alt="" />
		<br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">KELSEN</a>
		<br /><br />
		Las Danish Butter Cookies son un indulgente cl&aacute;sico que trasciende todas las fronteras. Con un 26% de manteca y un sabor adictivo, son de esos productos que nos acompa&ntilde;an desde hace d&eacute;cadas y que jam&aacute;s defraudan. Sus atractivas Cans redondas con innumerables dise&ntilde;os -  habitualmente devenidas en costurero - han servido como excusa a m&aacute;s de un consumidor para comprarlas sin tanta culpa. Estas delicias enmantecadas nos llegan a trav&eacute;s de Kelsen Group, el mayor fabricante mundial de Butter Cookies. Prohibidas si est&aacute;s a dieta.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/kelsen/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/kelsen/1.jpg" alt="" /></a>
			<div class="titulo_producto">Kelsen Famous<br />Danish Castles</div>
			Can Dise&ntilde;o <br />Contenido: 454g
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/kelsen/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/kelsen/2.jpg" alt="" /></a>
			<div class="titulo_producto">Kelsen Sign <br />of Zodiac</div>
			Can Dise&ntilde;o <br />Contenido: 454g
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/kelsen/3_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/kelsen/3.jpg" alt="" /></a>
			<div class="titulo_producto">Kelsen Funny <br />Animals</div>
			Can Dise&ntilde;o <br />Contenido: 454g
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/kelsen/4_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/kelsen/4.jpg" alt="" /></a>
			<div class="titulo_producto">Kelsen Winter <br />Nostalgic</div>
			Can Dise&ntilde;o <br />Contenido: 454g
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/kelsen/5_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/kelsen/5.jpg" alt="" /></a>
			<div class="titulo_producto">Kelsen Danish <br />Farm</div>
			Can Dise&ntilde;o <br />Contenido: 454g
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
