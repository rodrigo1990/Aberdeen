<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="../imagenes/productos/paises/belgica2.png" alt="" /></div>
	<div class="banners_productos">
		<img src="../imagenes/productos/banners/gulden.jpg" alt="GULDEN DRAAK" />
		<a href="http://www.vansteenberge.com/en/our-beer/gulden-draak/" target="_blank" >www.vansteenberge.com/en/our-beer/gulden-draak</a>
	</div>
	<div class="izquierda_productos">
		<img src="../imagenes/productos/logos/gulden.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">GULDEN DRAAK</a>
		<br /><br />
		Belgian beers Gulden Draak (or “Golden Dragon” in Flemish) owe their name to the gilded statue on top of the Belfry in Ghent, the city where Van Steenberge beers are brewed.
		<br /><br />
		Same as with other special beers of the Brewery Van Steenberge, Gulden Draak is a high fermentation product with secondary fermentation in which wine yeast is used.
		<br /><br />
		Gulden Draak is one of the world’s most valuable Belgian top beers and this is due to the quality of the ingredients used in its manufacturing process as well as to the admirable know-how that the Brewery Van Steenberge imparts to brew quality special beers.
		<br /><br />
		A unique beer deserves a unique presentation. That’s why Gulden Draak is presented in a white bottle. 
		<br /><br />
		The white bottle, the black banner, the golden dragon and the red letters result in an unequal style among the many Belgian special beers. 
		<br /><br />
		Gulden Draak can be drunk as an aperitif or dessert, or whenever you have the time to sit back and relax. 
		<br /><br />
		Discover its enchanting charm and taste this awesome beer! You will see how different it really is!
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/gulden/1_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/gulden/1.jpg" alt="" /></a>
			<div class="titulo_producto">Gulden Draak</div>
			Botella x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/gulden/2_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/gulden/2.jpg" alt="" /></a>
			<div class="titulo_producto">Gulden Draak<br />9000 Quadruple</div>
			Botella x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/gulden/4_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/gulden/4.jpg" alt="" /></a>
			<div class="titulo_producto">Gulden Draak</div>
			Barril 20lts (no retornable)
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/gulden/3_g.png" data-fancybox-group="gallery" ><img src="../imagenes/productos/gulden/3.jpg" alt="" /></a>
			<div class="titulo_producto">Gulden Draak<br />Gift Pack</div>
			1 GD  x 330ml + 1 GDQ9000 x 330ml + 1 copa
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
