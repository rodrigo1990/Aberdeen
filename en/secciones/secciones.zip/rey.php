<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="imagenes/productos/paises/espa.png" alt="" /></div>
	<div class="banners_productos">
		<img src="imagenes/productos/banners/rey.jpg" alt="Rey" />
		<a href="http://www.rey-alimentacion.com" target="_blank" >www.rey-alimentacion.com</a>
	</div>
	<div class="izquierda_productos">
		<img src="imagenes/productos/logos/rey.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">REY</a>
		<br /><br />
		Los Turrones de Almendra Rey son elaborados en la provincia de Badajoz, en Extremadura, desde hace m&aacute;s de 40 a&ntilde;os. Una empresa familiar y joven, sobre todo si consideramos que la primera versi&oacute;n espa&ntilde;ola del Turr&oacute;n naci&oacute; en Alicante alrededor del siglo XV.
		<br /><br />
		La calidad de los productos Rey muestra a las claras una pasi&oacute;n y una dedicaci&oacute;n que lleva el sello de las empresas familiares; ello se refleja en tres naturales turrones artesanales a base de almendras y miel: un Turr&oacute;n Blando, uno Duro y una Torta Imperial. Disponibles durante la temporada navide&ntilde;a y algo m&aacute;s.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/rey/1_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/rey/1.jpg" alt="" /></a>
			<div class="titulo_producto">Rey Turr&oacute;n<br />Blando de<br />Almendras</div>
			Caja x 150g
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/rey/2_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/rey/2.jpg" alt="" /></a>
			<div class="titulo_producto">Rey Turr&oacute;n Duro<br />de Almendras</div>
			Caja x 150g
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="imagenes/productos/rey/3_g.jpg" data-fancybox-group="gallery" ><img src="imagenes/productos/rey/3.jpg" alt="" /></a>
			<div class="titulo_producto">Rey Torta<br />Imperial de<br />Almendras</div>
			Caja x 150g
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
