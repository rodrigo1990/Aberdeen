<style>
.titulo_producto{
	padding-bottom: 20px;
}


</style>
<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="../imagenes/productos/paises/ItaliaPonti-79.png" alt="" /></div>
	<div class="banners_productos">
		<img src="../imagenes/productos/banners/czechvar.jpg" alt="CZECHVAR" />
		<a href="http://www.czechvar.com/index.html" target="_blank" >www.czechvar.com</a>
	</div>
	<div class="izquierda_productos">
		<img src="../imagenes/productos/logos/ponti.jpg" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">PONTI</a>
		<br /><br />
		<b>Ponti:</b> The # 1 brand of balsamic vinegars and gastronomic glaze in Italy is now in our country together with the finest line of vegetables and dressings ready to enjoy. These excellent products are the result of a delighted selection and blend of the ingredients, the constant technological innovation and the tightest quality and hygiene standards. 
		<br /><br />
		<b>Balsamic Vinegars of Modena:</b> Extraordinary in the kitchen and great on the table, Ponti Balsamic Vinegars of Modena are the result of a delighted blend between selected grape musts and precious wine vinegar, followed by a certified maturation period in different wooden core casks, providing their unique and irresistible taste.
		<br /><br />
		<b>Gastronomic Glaze:</b> High quality ingredients, low acidity, high density, sweet & sour taste, cooked must aroma, dark brilliant brown colour: these are the characteristics of the Ponti Glaze, an international success for your meals.
		<br /><br />
		<b>Vegetables in oil:</b>The most diverse Italian antipasti for which fresh raw materials and traditional recipes are used has arrived and it is possible to find it in Argentina now with its best flavors: skinned peppers, sundried tomatoes, artichokes, aubergines and pesto sauce. This is the ideal taste to enhance all of your meals: pasta, finger food, barbecue and wherever Ponti is present to boost your creativity. 
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/1_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/1.jpg" alt="" /></a>
			<div class="titulo_producto">Ponti<br />Balsamic Vinegar  <br> Di Modena</div>
			Bottle x 250ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/2_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/2.jpg" alt="" /></a>
			<div class="titulo_producto">Ponti<br />Balsamic Vinegar <br> Di Modena</div>
			Bottle x 500nl
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/3_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/3.jpg" alt="" /></a>
			<div class="titulo_producto">Ponti<br />Balsamic Vinegar<br>Di Modena Spray</div>
			Bottle Spray x 250ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/4_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/4.jpg" alt="" /></a>
			<div class="titulo_producto" style="padding-bottom:4px!important;">Ponti<br />Balsamic Vinegar <br> Di Modena Cápsula Oro 12M</div>
			Bottle x 250ml
		</div>
		
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/6_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/6.jpg" alt="" /></a>
			<div class="titulo_producto" style="padding-bottom:4px!important;">Ponti<br />Gastronomic Glassa <br> with Balsamic Vinegar</div>
			Bottle PET 250 ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/5_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/5.jpg" alt="" /></a>
			<div class="titulo_producto">Ponti<br />Balsamic Vinegar <br> Di Modena HD</div>
			Bottle with Case x 250ml

		</div>
		<div class="clear"></div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/7_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/7.jpg" alt="" /></a>
			<div class="titulo_producto" style="padding-bottom:3px">Ponti<br />Gastronomic Glassa <br /> with soy</div>
			Bottle PET 250ml
		</div>
		
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/8_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/8.jpg" alt="" /></a>
			<div class="titulo_producto">Ponti <br />Carciofini alle <br> Erbe Fini</div>
			Bottle x 280grs
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/9_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/9.jpg" alt="" /></a>
			<div class="titulo_producto" style="padding-bottom: 36px;">Ponti<br />Peperoni Grigliate</div>
			Bottle x 280gs
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/10_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/10.jpg" alt="" /></a>
			<div class="titulo_producto">Ponti<br />Melanzane Grigliate</div>
			Bottle x 280grs
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/11_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/11.jpg" alt="" /></a>
			<div class="titulo_producto">Ponti<br />Pesto <br> Pomodori Secchi</div>
			Barrel x 135grs
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/ponti/12_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/ponti/12.jpg" alt="" /></a>
			<div class="titulo_producto">Ponti<br />Pesto <br> alla Genovese</div>
			Barrel x 20lts <br>(no retornable)
		</div>
		
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
