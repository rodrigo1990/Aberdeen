<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="../imagenes/productos/paises/BelgicaLaChouffe-79.png" alt="" /></div>
	<div class="banners_productos">
		<img src="../imagenes/productos/banners/darguner.jpg" alt="Darguner" />
		<a href="http://www.brauerei-dargun.de" target="_blank" >www.brauerei-dargun.de</a>
	</div>
	<div class="izquierda_productos">
		<img src="../imagenes/productos/logos/chouffe.jpg" style="width:150px" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">LA CHOUFFE</a>
		<br /><br />
		Finally, the classical version of this unconventional Belgian beer has arrived. 
		<br /><br />
	 	It offers a beautiful intense golden colour plus a crown of creamy foam. With all that, this beer is just pure pleasure. It tastes spiced, with an outstanding touch of citrus followed by a refreshing aroma of coriander. This mixture turns this beer into a product especially fresh. The Blonde variety is an extraordinary beer with flavours that combine into a flowery character that is perfectly complemented by a banana-like fruitiness. It is a light and harmonic beer with a finish that is agreeably herbal and peppery.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/chouffe/1_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/chouffe/1.jpg" alt="" /></a>
			<div class="titulo_producto">La Choufee</div>
			Bottle x 330ml
		</div>
		
		
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
