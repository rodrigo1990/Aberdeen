<div class="titulos_secciones">Our Brands</div>
<div id="contiene_marcas">
	<div id="izquierda_marcas">
		BEERS
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		OTHER PRODUCTS
		<br /><br /><br /><br /><br /><br /><br /><br /><br />
	</div>
	<div id="derecha_marcas">
		<a href="?s=oranjeboom" ><img src="../imagenes/marcas_nuevas/1.png" alt="" /></a>
		<a href="?s=hertog" ><img src="../imagenes/marcas_nuevas/13.png" alt="" /></a>
		<a href="?s=horses" ><img src="../imagenes/marcas_nuevas/19.png" alt="" /></a>
		<a href="?s=darguner" ><img src="../imagenes/marcas_nuevas/18.png" alt="" /></a>
		<a href="?s=flensburger" ><img src="../imagenes/marcas_nuevas/20.png" alt="" /></a>
		<br>
		<a href="?s=weidmann" ><img src="../imagenes/marcas_nuevas/6.png" alt="" /></a>
		<a href="?s=gulden_draak" ><img src="../imagenes/marcas_nuevas/4.png" alt="" /></a>
		<a href="?s=westmalle" ><img src="../imagenes/marcas_nuevas/8.png" alt="" /></a>
		<a href="?s=piraat" ><img src="../imagenes/marcas_nuevas/12.png" alt="" /></a>
		<a href="?s=vedett" ><img src="../imagenes/marcas_nuevas/vedett_logo.png" alt="" /></a>
		<br>
		<a href="?s=duvel" ><img src="../imagenes/marcas_nuevas/duvel_logo.png" alt="" /></a>
		<a href="?s=maredsous" ><img src="../imagenes/marcas_nuevas/maredsous_logo.png" alt="" /></a>
		<a href="?s=choufee" ><img src="../imagenes/marcas_nuevas/chouffe_logo.png" alt="" /></a>
		<a href="?s=grimbergen" ><img src="../imagenes/marcas_nuevas/11.png" alt="" /></a>
		<a href="?s=kronenbourg" ><img src="../imagenes/marcas_nuevas/2.png" alt="" /></a>
		<br>
		<a href="?s=speckled" ><img src="../imagenes/marcas_nuevas/old_speckled_hen_logo.png" alt="" /></a>
		<a href="?s=abbot" ><img src="../imagenes/marcas_nuevas/abbot_ale_logo.png" alt="" /></a>
		<a href="?s=czechvar" ><img src="../imagenes/marcas_nuevas/5.png" alt="" /></a>
		<a href="?s=pilsner" ><img src="../imagenes/marcas_nuevas/pilsner_logo.png" alt="" /></a>
		<a href="?s=belhaven" ><img src="../imagenes/marcas_nuevas/belhaven_logo.png" alt="" /></a>
		<!-- 
		<a href="?s=fullers" ><img src="../imagenes/marcas_nuevas/3.png" alt="" /></a>		 -->
		<br>
		
		
		<a href="?s=coopers" ><img src="../imagenes/marcas_nuevas/7.png" alt="" /></a>
		<br /><br /><br /><br /><br />
		<a href="?s=inkakola" ><img src="../imagenes/marcas_nuevas/10.png" alt="" width="80px" /></a>
		<a href="?s=ponti" ><img src="../imagenes/marcas_nuevas/21.png" alt=""  width="120px"/></a>
		<a href="?s=krakus" ><img src="../imagenes/marcas_nuevas/22.png" alt="" width="50px" /></a>
		<a href="?s=pocoloco" ><img src="../imagenes/marcas_nuevas/23.png" alt="" width="80px" /></a>

		
		<br />
	</div>
</div>
