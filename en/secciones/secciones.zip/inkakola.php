<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="../imagenes/productos/paises/peru2.png" alt="" /></div>
	<div class="banners_productos">
		<img src="../imagenes/productos/banners/incakola.jpg" alt="Inka Kola" />
		<a href="http://www.incakola.com.pe" target="_blank" >www.incakola.com.pe</a>
	</div>
	<div class="izquierda_productos">
		<img src="../imagenes/productos/logos/incakola.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">INKA KOLA</a>
		<br /><br />
		Peruvian cuisine is internationally known by its variety and incredible flavours. Among those ones who enjoy it day by day in their country of origin, there are just a few who do not think of Inca Kola as the perfect drink to match the food. Inca Kola is the national drink in Peru and also something to be proud of as many Peruvians feel. It is this pride what makes it unique among its lovers (millions of Peruvians as well as other fans worldwide) and what also made it become almost a national icon. Inca Kola is a golden yellow, sweet soft drink with an unmistakable flavour. If you belong to the Land of the Incas your nostalgia has come to an end. Inca Kola is among us! Now, if you have not tried it yet, we encourage you to taste this new and unique flavour! 
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/incakola/1_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/incakola/1.jpg" alt="" /></a>
			<div class="titulo_producto">Inca Kola<br />Soda</div>
			Bottle x 2,25lts
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/incakola/2_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/incakola/2.jpg" alt="" /></a>
			<div class="titulo_producto">Inca Kola<br />Soda</div>
			Bottle x 1,50lts
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
