<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="../imagenes/productos/paises/RepChecaPilsner-79.png" alt="" /></div>
	<div class="banners_productos">
		<img src="../imagenes/productos/banners/flensburger.jpg" alt="flensburger" />
		<a href="http://www.flens.de" target="_blank" >www.flens.de</a>
	</div>
	<div class="izquierda_productos">
		<img src="../imagenes/productos/logos/pilsner.jpg" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">PILSNER URQUELL </a>
		<br /><br />
		This is a low-fermentation beer that has been produced since 1842 in the City of Pilsen, Bohemia (Czech Republic).
		<br /><br />
		It is called the "model of meter" among beers as all other pilsners are a better or worse attempt to copy the original - the first ever Pilsner Urquell. Su excepcionalidad sin igual está garantizada la misma receta que data de 1842. Its unparalleled exceptionality is guaranteed by the same recipe dating from 1842.
		<br /><br />
		It was the first Pilsener beer in history, which was manufactured by a Bavarian brewer called Josef Groll. Pilsner Urquell is now a symbol and any beer that is considered as a Pilsner, Pilsener or Pils is related in one way or another to a variant of this style of beer.
		<br /><br />
		Pilsner Urquell has a floral aroma as Saaz, a "noble" variety of hops, are used for its brewing. As a lager beer, it is considered clean, that is, non-fruity. Besides, it strongly tastes to malt in comparison with other Pilsner beers due to a decoction mashing process. Even when it is sourer than most of the beers of its kind, its bitterness is not persistent as soft water is used at the brewery. Its ABV is 4.4%, lower than the alcoholic content for other lager beers.
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/pilsner/1_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/pilsner/1.jpg" alt="" /></a>
			<div class="titulo_producto">Pilsner Urquell<br />Pale Lager</div>
			Bottle x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/pilsner/2_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/pilsner/2.jpg" alt="" /></a>
			<div class="titulo_producto">Pilsner Urquell<br />Pale Lager</div>
			 Can x 500ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/pilsner/3_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/pilsner/3.jpg" alt="" /></a>
			<div class="titulo_producto">Pilsner Urquell<br />Pale Lager</div>
			 Bottle x  500ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/pilsner/4_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/pilsner/4.jpg" alt="" /></a>
			<div class="titulo_producto">Pilsner Urquell<br />Pale Lager</div>
			Barrel x 20lts <br> (non-returnable)
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
