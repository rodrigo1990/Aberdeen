<script type="text/javascript" src="js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript">
	$(document).ready(function() {
		$('.fancybox').fancybox();
	});
</script>

<div class="centra960">
	<div class="paises_productos"><img src="../imagenes/productos/paises/belgica2.png" alt="" /></div>
	<div class="banners_productos">
		<img src="../imagenes/productos/banners/piraat.jpg" alt="PIRAAT" />
		<a href="http://www.vansteenberge.com/es/nuestras-cervezas/piraat/" target="_blank" >www.vansteenberge.com/es/nuestras-cervezas/piraat/</a>
	</div>
	<div class="izquierda_productos">
		<img src="../imagenes/productos/logos/piraat.png" alt="" />
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<img src="imagenes/productos/variedad.png" alt="" />
	</div>
	<div class="derecha_productos">
		<a class="titulos_productos">PIRAAT</a>
		<br /><br />
		Piraat is a Belgian beer, Belgian Strong Pale Ale style, launched in 1982 by Van Steenberge Brewery, in Ghent. 
		<br /><br />
		It is manufactured with natural ingredients and no less than three types of malt (Pale Ale, Pilsener and Munich) and bitter hops (Aurora and Petra). 
		<br /><br />
		This is a perfect combination for a special beer with malty, sweet and hopbitter tastes.
		<br /><br />
		During its brewing process, fermentation takes place both in the bottle and in the barrel, ensuring preservability for years with an evolution in taste. 
		<br /><br />
		Its full foam head lasts until the final sip.
		<br /><br />
		This top-quality strong Belgian beer has a unique character. It is excellent in all aspects.<br />
		Happy drinking!
		<br /><br />
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/piraat/1_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/piraat/1.jpg" alt="" /></a>
			<div class="titulo_producto">Piraat</div>
			Bottle x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/piraat/2_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/piraat/2.jpg" alt="" /></a>
			<div class="titulo_producto">Piraat Triple<br />Hop</div>
			Bottle x 330ml
		</div>
		<div class="contiene_producto">
			<a class="fancybox" href="../imagenes/productos/piraat/3_g.jpg" data-fancybox-group="gallery" ><img src="../imagenes/productos/piraat/3.jpg" alt="" /></a>
			<div class="titulo_producto">Piraat <br />Gift Pack</div>
			1 Piraat 330ml + 1 Piraat Triple Hop 330ml + 1 Cup
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
